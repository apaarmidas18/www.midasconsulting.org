import React from 'react'

const Blackheading = ({head}) => {
  return (
    <>
<h2 className='black-head'>{head}</h2>    
    </>
  )
}

export default Blackheading
import React from 'react'

const Buttonwhite = ({buttonTitle}) => {
  return (
    <>
    <button className='banner-btn'>{buttonTitle}</button>
    
    </>
  )
}

export default Buttonwhite
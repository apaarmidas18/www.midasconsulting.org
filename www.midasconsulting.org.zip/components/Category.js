import React from 'react'

const Category = ({spantitle}) => {
  return (
    <>
    <span className='category-span'>{spantitle}</span>
    
    </>
  )
}

export default Category
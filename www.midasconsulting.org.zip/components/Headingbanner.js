import React from 'react'

const Headingbanner = ({title}) => {
  return (
    <>
    <div className='container-fluid color-banner'>
        <h2>{title}</h2>
    </div>
    
    </>
  )
}

export default Headingbanner
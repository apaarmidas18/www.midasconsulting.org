import React from 'react'

const Lightheading = ({light}) => {
  return (
    <>
    <h2 className='lightheading'>{light}</h2>
    
    </>
  )
}

export default Lightheading
import React from 'react'

const Paragraph = ({para}) => {
  return (
    <>
    
    <p className='paragraph'>{para}</p>
    
    </>
  )
}

export default Paragraph
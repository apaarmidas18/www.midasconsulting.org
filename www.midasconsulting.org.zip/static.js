export const host = "https://checklist.midascrm.tech/";
// export const host = "http://192.168.1.42:9000/";
